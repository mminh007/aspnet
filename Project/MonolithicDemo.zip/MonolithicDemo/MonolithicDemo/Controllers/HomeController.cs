using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MonolithicDemo.Models;
using MonolithicDemo.Services;

namespace MonolithicDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private  readonly IProductService _productService;

        public HomeController(ILogger<HomeController> logger, IProductService _prod)
        {
            _logger = logger;
            _productService = _prod;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Products()
        {
            var products = _productService.GetAllProductsAsync().Result;
            return View(products);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
