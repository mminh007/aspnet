﻿using MonolithicDemo.Models;

namespace MonolithicDemo.Repositories
{
    public interface IProductRepository
    {
        public Task<IEnumerable<Product>> GetAllProductsAsync(bool includeNavigation = false);

        public Task<Product?> GetProductByIdAsync(int id, bool includeNavigation = false);

        public Task<Product?> CreateProductAsync(Product product, bool includeNavigation = false);

        public Task<Product?> UpdateProductAsync(Product product, bool includeNavigation = false);

        public Task<bool> DeleteProductAsync(int id, bool includeNavigation = false);
    }
}
