﻿using Microsoft.EntityFrameworkCore;
using MonolithicDemo.Databases;
using MonolithicDemo.Models;

namespace MonolithicDemo.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDBContext _dbcontext;

        public ProductRepository(AppDBContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public async Task<Product?> CreateProductAsync(Product product, bool includeNavigation = false)
        {
            await _dbcontext.Products.AddAsync(product);
            return product;

        }

        public async Task<bool> DeleteProductAsync(int id, bool includeNavigation = false)
        {
            var product = await GetProductByIdAsync(id, includeNavigation:false);
            if (product == null)
            {
                return false;
            }

            await _dbcontext.Products
                .Where(p => p.Id == id)
                .ExecuteDeleteAsync();
            return true;

        }

        public async Task<Product?> UpdateProductAsync(Product product, bool includeNavigation = false)
        {
            var existingProduct = await _dbcontext.Products
                .FirstOrDefaultAsync(p => p.Id == product.Id);

            if (existingProduct == null)
            {
                return null;
            }
            existingProduct = new Product
            {
                Id = product.Id,
                ProductName = product.ProductName,
                SupplierId = product.SupplierId,
                UnitPrice = product.UnitPrice,
                Package = product.Package,
                IsDiscontinued = product.IsDiscontinued
            };

            //_dbcontext.Products.Update(existingProduct);
            //await _dbcontext.SaveChangesAsync();
            return existingProduct;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync(bool includeNavigation = false)
        {
            if (includeNavigation)
            {
                return await _dbcontext.Products
                    .Include(p => p.Supplier)
                    .Include(p => p.OrderItems)
                    .ToListAsync();
            }
            return await _dbcontext.Products.ToListAsync();
        }

        public async Task<Product?> GetProductByIdAsync(int id, bool includeNavigation = false)
        {
            if (includeNavigation)
            {
                return await _dbcontext.Products
                    .Include(p => p.Supplier)
                    .Include(p => p.OrderItems)
                    .FirstOrDefaultAsync(p => p.Id == id);
            }

            return await _dbcontext.Products.FirstOrDefaultAsync(p => p.Id == id);
        }
    }
}
