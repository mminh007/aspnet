﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MonolithicDemo.Databases;
using MonolithicDemo.Models;
using MonolithicDemo.Repositories;
using MonolithicDemo.UnitOfWorks;
using System.Web.Http.ModelBinding;

namespace MonolithicDemo.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ITransactionsManagement _transactionsManagement;

        public ProductService(IProductRepository productRepository, ITransactionsManagement transactions)
        {
            _productRepository = productRepository;
            _transactionsManagement = transactions;
        }

        public async Task<Product> AddProductAsync(ProductDtoModel product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product), "Product cannot be null");
            }
            // Map ProductDtoModel to Product entity
            var productEntity = new Product
            {
                ProductName = product.ProductName,
                SupplierId = product.SupplierId,
                UnitPrice = product.UnitPrice,
                Package = product.Package,
                IsDiscontinued = product.IsDiscontinued
            };

            await _transactionsManagement.BeginAsync();
            try
            {
                var createdProduct = await _productRepository.CreateProductAsync(productEntity, includeNavigation: false);
                if (createdProduct == null)
                {
                    throw new Exception("Failed to create product.");
                }
                await _transactionsManagement.SaveChangesAsync();
                await _transactionsManagement.CommitAsync();

                return createdProduct;
            }
            catch
            {
                await _transactionsManagement.RollbackAsync();
                throw;
            }

        }

        public async Task<bool> DeleteProductAsync(int id)
        {
            await _transactionsManagement.BeginAsync();
            try
            {
                var isDeleted = await _productRepository.DeleteProductAsync(id, includeNavigation: false);
                if (!isDeleted)
                {
                    throw new Exception("Failed to delete product.");
                }
                await _transactionsManagement.CommitAsync();
                return true;
            }
            catch
            {
                await _transactionsManagement.RollbackAsync();
                throw;
            }
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync(bool includeNavigation = false)
        {
            var products = await _productRepository.GetAllProductsAsync(includeNavigation);
            if (products == null)
            {
                throw new Exception("No products found.");
            }
            return products;
        }

        public async Task<Product?> GetProductByIdAsync(int id, bool includeNavigation = false)
        {
            var product = await _productRepository.GetProductByIdAsync(id, includeNavigation);
            if (product == null)
            {
                throw new Exception($"Product with ID {id} not found.");
            }
            return product;
        }

        public async Task<Product> UpdateProductAsync(int id, ProductUpdateDto product)
        {
            var existingProduct = await _productRepository.GetProductByIdAsync(id, includeNavigation: false);

            foreach (var prop in product.GetType().GetProperties())
            {
                var value = prop.GetValue(product);
                if (value != null)
                {
                    var propInfo = existingProduct.GetType().GetProperty(prop.Name);
                    if (propInfo != null && propInfo.CanWrite)
                    {
                        propInfo.SetValue(existingProduct, value);
                    }
                }
            }


            await _transactionsManagement.BeginAsync();
            try             
            {
                var updatedProduct = await _productRepository.UpdateProductAsync(existingProduct, includeNavigation: false);
                if (updatedProduct == null)
                {
                    throw new Exception("Failed to update product.");
                }
                await _transactionsManagement.SaveChangesAsync();
                await _transactionsManagement.CommitAsync();
                return updatedProduct;
            }
            catch
            {
                await _transactionsManagement.RollbackAsync();
                throw;
            }
        }
    }
}
