﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using MonolithicDemo.Models;

namespace MonolithicDemo.Services
{
    public interface IProductService
    {
        Task<Product> AddProductAsync(ProductDtoModel product);

        Task<Product> UpdateProductAsync(int id, ProductUpdateDto product);

        Task<bool> DeleteProductAsync(int id);

        Task<Product?> GetProductByIdAsync(int id, bool includeNavigation = false);

        Task<IEnumerable<Product>> GetAllProductsAsync(bool includeNavigation = false);

        //Task<IEnumerable<Product>> GetProductsBySupplierIdAsync(int supplierId, bool includeNavigation = false);

        //Task<IEnumerable<Product>> GetProductsByNameAsync(string productName, bool includeNavigation = false);

        //Task<IEnumerable<Product>> GetProductsByCategoryIdAsync(int categoryId, bool includeNavigation = false);




    }
}
