﻿using Microsoft.EntityFrameworkCore.Storage;
using MonolithicDemo.Databases;

namespace MonolithicDemo.UnitOfWorks
{
    public class TransactionsManagement : ITransactionsManagement
    {
        private readonly AppDBContext _db;
        private IDbContextTransaction? _tx;
        public TransactionsManagement(AppDBContext db) => _db = db;

        public async Task BeginAsync() => _tx = await _db.Database.BeginTransactionAsync();
        public Task CreateSavepointAsync(string n) => _tx!.CreateSavepointAsync(n);
        public Task RollbackToAsync(string n) => _tx!.RollbackToSavepointAsync(n);
        public Task CommitAsync() => _tx!.CommitAsync();
        public Task RollbackAsync() => _tx!.RollbackAsync();

        public Task SaveChangesAsync() => _db.SaveChangesAsync();
        //public void Dispose()
        //{
        //    _tx?.Dispose();
        //    _tx = null;
        //}


    }
}
