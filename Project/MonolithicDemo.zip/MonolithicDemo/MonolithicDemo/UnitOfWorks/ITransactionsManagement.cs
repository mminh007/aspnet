﻿namespace MonolithicDemo.UnitOfWorks
{
    public interface ITransactionsManagement
    {
        Task BeginAsync();
        Task CreateSavepointAsync(string name);
        Task RollbackToAsync(string name);
        Task CommitAsync();
        Task RollbackAsync();
        Task SaveChangesAsync();
        
    }
}
